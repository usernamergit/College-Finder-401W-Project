"""Check packaged import paths, CSV structure, keys, and program references."""
import csv,re
from pathlib import Path

root=Path(__file__).parent/'mysql_database'
sql_files=set()
csv_paths=set()
def visit(path):
    if path in sql_files: return
    assert path.is_file(),f'Missing SQL file: {path}'
    sql_files.add(path)
    text=path.read_text()
    for source in re.findall(r'^SOURCE\s+(.+)$',text,re.M):
        visit(root/source.strip().rstrip(';'))
    for source in re.findall(r"LOCAL INFILE '([^']+)'",text):
        csv_paths.add(root/source)

visit(root/'00_LOAD_EVERYTHING.sql')
institutions=set();program_ids=set();counts={}
for path in sorted(csv_paths):
    assert path.is_file(),f'Missing CSV: {path}'
    with path.open(newline='',encoding='utf-8-sig') as handle:
        reader=csv.DictReader(handle)
        count=0;keys=set()
        for row in reader:
            assert None not in row and None not in row.values(),f'Malformed row in {path}'
            count+=1
            if path.name=='institutions.csv':
                institutions.add(row['unit_id']);key=(row['unit_id'],)
            elif path.name=='program_snapshots.csv':
                program_ids.add(row['unit_id'])
                key=tuple(row[c] for c in ('unit_id','cip_code','credential_level_id','release_id'))
            elif path.name=='institution_snapshots.csv':
                key=(row['unit_id'],row['release_id'])
            elif path.name=='cip_codes.csv': key=(row['cip_code'],)
            else: key=(row['credential_level_id'],)
            assert key not in keys,f'Duplicate key in {path}: {key}'
            keys.add(key)
        counts[path.name]=counts.get(path.name,0)+count
assert not program_ids-institutions,f'Unresolved institution IDs: {program_ids-institutions}'
print('PASS:',len(sql_files),'SQL files;',len(csv_paths),'CSV files;',len(institutions),'unique institutions')
print('Source row totals:',counts)
print('All program institutions exist; CSV keys and column widths passed.')
