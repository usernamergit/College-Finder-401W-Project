import csv
from django.http import Http404,HttpResponse
from django.shortcuts import render
from .forms import SearchForm
from . import services

def safe_csv(value):
    # Prevent spreadsheet formulas when an exported name starts with a formula marker.
    if isinstance(value,str) and value.lstrip().startswith(('=','+','-','@')):
        return "'"+value
    return value

def csv_response(records,columns,filename):
    response=HttpResponse(content_type='text/csv; charset=utf-8')
    response['Content-Disposition']='attachment; filename="'+filename+'"'
    writer=csv.writer(response)
    writer.writerow(columns)
    for record in records:
        writer.writerow([safe_csv(record.get(c)) for c in columns])
    return response

def search(request):
    mode='programs' if request.GET.get('mode')=='programs' else 'colleges'
    years,program_years,credentials=services.choices()
    selected_years=program_years if mode=='programs' else years
    form=SearchForm(request.GET or None,
        years=[y['academic_year'] for y in selected_years],
        credentials=[(c['credential_level_id'],c['credential_description']) for c in credentials])
    records=[]
    if not form.is_bound or form.is_valid():
        filters=form.cleaned_data if form.is_bound else {}
        records=(services.program_search if mode=='programs' else services.college_search)(filters)
    truncated=len(records)>200
    records=records[:200]
    if request.GET.get('format')=='csv' and (not form.is_bound or form.is_valid()):
        columns=['unit_id','institution_name','state_code']
        columns+=['cip_code','credential_description','program_academic_year','release_id','awards_year_1','awards_year_2','median_debt','median_earnings_1yr'] if mode=='programs' else ['academic_year','release_id','undergraduate_enrollment','in_state_tuition','enrollment_growth_pct','tuition_growth_pct','enrollment_trend']
        return csv_response(records,columns,mode+'.csv')
    query=request.GET.copy();query['format']='csv'
    return render(request,'analytics/search.html',{'form':form,'records':records,
        'mode':mode,'truncated':truncated,'export_query':query.urlencode()})

def detail(request,unit_id):
    institutions=services.rows('SELECT * FROM institution WHERE unit_id=%s',[unit_id])
    if not institutions: raise Http404('College not found')
    history=services.college_history(unit_id)
    if request.GET.get('format')=='csv':
        return csv_response(history,['academic_year','release_id','undergraduate_enrollment',
            'enrollment_change','enrollment_growth_pct','in_state_tuition',
            'tuition_change','tuition_growth_pct','enrollment_trend'],'college-history.csv')
    chart=[{'year':r['academic_year'],'enrollment':r['undergraduate_enrollment'],
            'tuition':r['in_state_tuition']} for r in history]
    return render(request,'analytics/detail.html',{'college':institutions[0],
        'history':history,'chart':chart})

def compare(request):
    years,_,_=services.choices()
    available=[r['academic_year'] for r in years]
    year=request.GET.get('year') or (available[0] if available else '')
    ids=[];error='';records=[]
    try:
        ids=list(dict.fromkeys(int(v.strip()) for v in request.GET.get('ids','').split(',') if v.strip()))
        if any(v<=0 for v in ids) or len(ids)>3: raise ValueError
        if year not in available and available: raise ValueError
        if ids: records=services.compare_colleges(ids,year)
        if ids and len(records)<len(ids): error='Some selected colleges have no record for this year.'
    except ValueError:
        error='Enter up to three positive UNITIDs and select an available year.'
    return render(request,'analytics/compare.html',{'records':records,'years':available,
        'year':year,'ids':request.GET.get('ids',''),'error':error})
