from django import forms
STATES=[('', 'All states')]+[(s,s) for s in ('CT','ME','MA','NH','RI','VT')]
class SearchForm(forms.Form):
    q=forms.CharField(required=False,max_length=100,label='College or program')
    state=forms.ChoiceField(required=False,choices=STATES)
    year=forms.ChoiceField(required=False,choices=[])
    credential=forms.TypedChoiceField(required=False,coerce=int,empty_value=None,choices=[])
    def __init__(self,*args,years=(),credentials=(),**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['year'].choices=[('', 'Latest available release')]+[(y,y) for y in years]
        self.fields['credential'].choices=[('', 'All credentials')]+list(credentials)
