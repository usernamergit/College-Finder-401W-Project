from django.conf import settings
from django.db import connections

def rows(sql,params=()):
    # SQL text is developer-controlled; user values are always bound parameters.
    with connections[getattr(settings,'COLLEGE_DB_ALIAS','default')].cursor() as cursor:
        cursor.execute(sql,params)
        columns=[c[0] for c in cursor.description]
        return [dict(zip(columns,row)) for row in cursor.fetchall()]

def choices():
    years=rows("SELECT DISTINCT academic_year FROM v_institution_annual ORDER BY academic_year DESC")
    programs=rows("SELECT DISTINCT program_academic_year AS academic_year FROM source_release WHERE program_academic_year IS NOT NULL ORDER BY program_academic_year DESC")
    credentials=rows('SELECT credential_level_id,credential_description FROM credential_level ORDER BY credential_level_id')
    return years,programs,credentials

def college_search(filters):
    if filters.get('year'):
        sql=('SELECT i.unit_id,i.institution_name,i.city,i.state_code,a.* '
             'FROM institution i JOIN v_institution_yearly_changes a ON a.unit_id=i.unit_id '
             'WHERE a.academic_year=%s')
        params=[filters['year']]
    else:
        sql='SELECT * FROM v_college_latest WHERE 1=1'
        params=[]
    if filters.get('state'):
        sql+=' AND state_code=%s';params.append(filters['state'])
    if filters.get('q'):
        sql+=' AND institution_name LIKE %s';params.append('%'+filters['q']+'%')
    return rows(sql+' ORDER BY institution_name,unit_id LIMIT 201',params)

def program_search(filters):
    sql='SELECT p.* FROM v_program_search p '
    params=[]
    if not filters.get('year'):
        sql+='JOIN v_latest_program_release r ON r.release_id=p.release_id '
    sql+='WHERE 1=1'
    if filters.get('year'):
        sql+=' AND p.program_academic_year=%s';params.append(filters['year'])
    if filters.get('state'):
        sql+=' AND p.state_code=%s';params.append(filters['state'])
    if filters.get('credential') is not None:
        sql+=' AND p.credential_level_id=%s';params.append(filters['credential'])
    if filters.get('q'):
        sql+=' AND (p.cip_description LIKE %s OR p.institution_name LIKE %s)'
        params.extend(['%'+filters['q']+'%']*2)
    return rows(sql+' ORDER BY p.institution_name,p.cip_code,p.credential_level_id,p.release_id LIMIT 201',params)

def college_history(unit_id):
    return rows('SELECT * FROM v_institution_yearly_changes WHERE unit_id=%s ORDER BY year_start',[unit_id])

def compare_colleges(ids,year):
    placeholders=','.join(['%s']*len(ids))
    return rows('SELECT i.institution_name,a.* FROM v_institution_yearly_changes a '
                'JOIN institution i ON i.unit_id=a.unit_id WHERE a.unit_id IN ('+
                placeholders+') AND a.academic_year=%s ORDER BY i.institution_name',[*ids,year])
