from django.urls import path
from . import views
app_name='analytics'
urlpatterns=[path('',views.search,name='search'),
 path('college/<int:unit_id>/',views.detail,name='detail'),
 path('compare/',views.compare,name='compare')]
