from pathlib import Path
import os,secrets,pymysql
pymysql.install_as_MySQLdb()
BASE_DIR=Path(__file__).resolve().parent.parent
SECRET_KEY=os.environ.get('DJANGO_SECRET_KEY') or secrets.token_urlsafe(50)
DEBUG=os.environ.get('DJANGO_DEBUG','1')=='1'
ALLOWED_HOSTS=['127.0.0.1','localhost','testserver']
INSTALLED_APPS=['analytics']
MIDDLEWARE=['django.middleware.security.SecurityMiddleware',
 'django.middleware.common.CommonMiddleware','django.middleware.csrf.CsrfViewMiddleware',
 'django.middleware.clickjacking.XFrameOptionsMiddleware']
ROOT_URLCONF='config.urls'
TEMPLATES=[{'BACKEND':'django.template.backends.django.DjangoTemplates',
 'DIRS':[],'APP_DIRS':True,'OPTIONS':{'context_processors':[
 'django.template.context_processors.request']}}]
DATABASES={'default':{'ENGINE':'django.db.backends.mysql',
 'NAME':os.environ.get('DB_NAME','new_england_college_data'),
 'USER':os.environ.get('DB_USER','root'),
 'PASSWORD':os.environ.get('DB_PASSWORD',''),
 'HOST':os.environ.get('DB_HOST','127.0.0.1'),
 'PORT':os.environ.get('DB_PORT','3306'),
 'OPTIONS':{'charset':'utf8mb4'}}}
COLLEGE_DB_ALIAS='default'
USE_TZ=True
TIME_ZONE='America/New_York'
DEFAULT_AUTO_FIELD='django.db.models.BigAutoField'
