from .settings import *
# Isolated synthetic tests only. Never points at the user's MySQL database.
DATABASES={'default':{'ENGINE':'django.db.backends.sqlite3','NAME':':memory:'}}
