"""Synthetic SQL and HTTP tests. Run: python run_tests.py (no MySQL needed)."""
import os,re,unittest
from pathlib import Path
os.environ['DJANGO_SETTINGS_MODULE']='config.test_settings'
import django
django.setup()
from django.db import connection
from django.test import Client
from analytics import services

ROOT=Path(__file__).resolve().parents[1]

class AnalyticsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db=connection.ensure_connection()
        raw=connection.connection
        raw.executescript('''
        CREATE TABLE source_release (release_id TEXT PRIMARY KEY,release_date TEXT,
          institution_academic_year TEXT,program_academic_year TEXT);
        CREATE TABLE institution (unit_id INTEGER PRIMARY KEY,institution_name TEXT,
          city TEXT,state_code TEXT,institution_url TEXT);
        CREATE TABLE institution_snapshot (unit_id INTEGER,release_id TEXT,
          undergraduate_enrollment INTEGER,in_state_tuition REAL,out_of_state_tuition REAL,
          admission_rate REAL,full_time_retention_4yr REAL,full_time_retention_lt4yr REAL,
          completion_rate_150_4yr REAL,completion_rate_150_lt4yr REAL);
        CREATE TABLE cip_code (cip_code TEXT,cip_display TEXT,cip_description TEXT);
        CREATE TABLE credential_level (credential_level_id INTEGER,credential_description TEXT);
        CREATE TABLE program_snapshot (unit_id INTEGER,cip_code TEXT,credential_level_id INTEGER,
          release_id TEXT,awards_year_1 INTEGER,awards_year_2 INTEGER,
          median_debt REAL,median_earnings_1yr REAL,median_earnings_4yr REAL,median_earnings_5yr REAL);
        INSERT INTO institution VALUES (1,'Test College','Providence','RI',NULL),
          (2,'Zero College','Boston','MA',NULL),(3,'Missing College','Hartford','CT',NULL);
        INSERT INTO cip_code VALUES ('1107','11.07','Computer Science');
        INSERT INTO credential_level VALUES (3,'Bachelor');
        ''')
        releases=[('r20','2021-01-01','2020-21','2020-21'),
          ('r21','2022-01-01','2021-22','2021-22'),
          ('r21new','2022-02-01','2021-22',None),
          ('r23','2024-01-01','2023-24',None),
          ('r24','2025-01-01','2024-25',None),
          ('r25','2026-01-01','2025-26',None)]
        raw.executemany('INSERT INTO source_release VALUES (?,?,?,?)',releases)
        data=[(1,'r20',1000,10000),(1,'r21',999,9000),(1,'r21new',1100,11000),
          (1,'r23',1300,12000),(1,'r24',1000,12600),(1,'r25',0,12600),
          (2,'r24',0,0),(2,'r25',50,1000),(3,'r24',None,None),(3,'r25',0,0)]
        raw.executemany('INSERT INTO institution_snapshot VALUES (?,?,?,?,NULL,NULL,NULL,NULL,NULL,NULL)',data)
        raw.executemany('INSERT INTO program_snapshot VALUES (?,?,?,?,?,?,?,?,?,?)',[
          (1,'1107',3,'r20',10,20,None,50000,None,None),
          (1,'1107',3,'r21',10,15,0,55000,None,None)])
        sql=(ROOT/'mysql_database/sql/06_analytics.sql').read_text()
        sql=re.sub(r'^USE .*?;\s*','',sql,flags=re.M)
        sql=sql.replace('CREATE OR REPLACE VIEW','CREATE VIEW')
        raw.executescript(sql)
        cls.client=Client()

    def test_growth_and_duplicate_resolution(self):
        r=services.college_history(1)
        self.assertEqual(len(r),5)
        self.assertEqual(r[1]['enrollment_change'],100)
        self.assertEqual(r[1]['enrollment_growth_pct'],10)
        self.assertEqual(r[1]['tuition_growth_pct'],10)
    def test_gap(self):
        r=services.college_history(1)[2]
        self.assertIsNone(r['enrollment_growth_pct'])
        self.assertIsNone(r['tuition_growth_pct'])
    def test_decline(self):
        r=services.college_history(1)[3]
        self.assertEqual(r['enrollment_change'],-300)
        self.assertEqual(r['enrollment_growth_pct'],-23.08)
        self.assertEqual(r['enrollment_trend'],'Declining')
    def test_zero_denominator(self):
        r=services.college_history(2)[-1]
        self.assertEqual(r['enrollment_change'],50)
        self.assertIsNone(r['enrollment_growth_pct'])
        self.assertIsNone(r['tuition_growth_pct'])
    def test_missing(self):
        self.assertIsNone(services.college_history(3)[-1]['enrollment_change'])
    def test_latest_dataset_selection(self):
        self.assertEqual(services.rows('SELECT release_id FROM v_latest_institution_release')[0]['release_id'],'r25')
        self.assertEqual(services.rows('SELECT release_id FROM v_latest_program_release')[0]['release_id'],'r21')
        self.assertEqual(len(services.program_search({})),1)
    def test_filters_and_injection(self):
        self.assertEqual(len(services.college_search({'state':'RI'})),1)
        self.assertEqual(services.college_search({'q':"' OR 1=1 --"}),[])
    def test_pages(self):
        for url in ['/analytics/','/analytics/?mode=programs','/analytics/college/1/',
                    '/analytics/compare/?ids=1,2&year=2025-26']:
            with self.subTest(url=url): self.assertEqual(self.client.get(url).status_code,200)
        self.assertEqual(self.client.get('/analytics/college/999/').status_code,404)
    def test_invalid_filters(self):
        for query in ['state=XX','year=1900-01','credential=abc']:
            self.assertContainsText('/analytics/?'+query,'Select a valid choice')
        self.assertContainsText('/analytics/compare/?ids=1,2,3,4','up to three')
    def assertContainsText(self,url,text):
        response=self.client.get(url)
        self.assertEqual(response.status_code,200)
        self.assertIn(text,response.content.decode())
    def test_csv_and_zero_display(self):
        response=self.client.get('/analytics/college/1/?format=csv')
        self.assertEqual(response['Content-Type'],'text/csv; charset=utf-8')
        self.assertIn('enrollment_growth_pct',response.content.decode())
        self.assertIn(',0,',response.content.decode())
        self.assertContainsText('/analytics/?mode=programs','>0.0<')
    def test_release_awards_decline(self):
        r=services.rows('SELECT awards_change FROM v_program_release_change ORDER BY release_date')
        self.assertEqual(r[-1]['awards_change'],-5)

if __name__=='__main__': unittest.main(verbosity=2)
