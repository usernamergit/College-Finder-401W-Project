param(
 [string]$MySqlPath = '',
 [string]$User = 'root',
 [switch]$FullImport
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not $MySqlPath) {
 $found = Get-Command mysql.exe -ErrorAction SilentlyContinue
 if ($found) { $MySqlPath = $found.Source }
 else {
  $candidates = @(Get-ChildItem 'C:\Program Files\MySQL' -Filter mysql.exe -Recurse -ErrorAction SilentlyContinue)
  if ($candidates.Count -eq 1) { $MySqlPath = $candidates[0].FullName }
  elseif ($candidates.Count -gt 1) {
   $candidates.FullName | Write-Host
   throw 'Multiple installations found. Rerun with -MySqlPath followed by the desired path.'
  } else { throw 'mysql.exe not found. Rerun with -MySqlPath followed by its full path.' }
 }
}
$sqlFile = '01_UPDATE_EXISTING.sql'
if ($FullImport) { $sqlFile = '00_LOAD_EVERYTHING.sql' }
Write-Host "Running $sqlFile. Enter your MySQL password when prompted."
& $MySqlPath '--local-infile=1' '-u' $User '-p' '--execute' "source $sqlFile"
if ($LASTEXITCODE -ne 0) { throw "MySQL exited with code $LASTEXITCODE. Review the errors above." }
Write-Host 'Finished. Review the validation results above for any errors or missing records.'
