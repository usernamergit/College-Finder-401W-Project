> October 29 update: start with ../README_START_HERE.md. Existing databases use Run-Database.ps1 without -FullImport. The notes below describe the earlier initial import.

# New England College Database — Combined Import

This package combines the validated College Scorecard institution and field-of-study files into one MySQL import. You only need to extract the ZIP, open the extracted folder in VS Code, and run one command.

## Before running

1. Confirm MySQL Server is running.
2. In VS Code, open **Terminal > New Terminal**.
3. Make sure PowerShell is inside the extracted folder—the same folder that contains `00_LOAD_EVERYTHING.sql`.

## One-command import (PowerShell)

```powershell
cmd /c "mysql --local-infile=1 -u root -p < 00_LOAD_EVERYTHING.sql"
```

Enter your MySQL root password when prompted. The password will not appear while you type; this is normal.

The script will automatically:

- create the `new_england_college_data` database and tables;
- load the institution and program datasets in foreign-key-safe order;
- create the analysis views; and
- run final count and integrity checks.

The loaders use `IGNORE`, so rerunning the package will not duplicate primary-key rows or overwrite an existing historical row with blank data.

## Included coverage

| Academic year | Institution data | Field-of-study data | Notes |
|---|---:|---:|---|
| 2015–16 | No matching file supplied | Yes | Programs are limited to institutions identifiable from the supplied New England institution lists. |
| 2016–17 through 2022–23 | Yes | Yes | Matched annual institution and program releases. |
| 2023–24 | Yes | Latest supplied program outcomes also identify 2023–24 | The incomplete 35-institution rebuild is intentionally excluded. |
| 2024–25 | Yes | No separate file supplied | Institution-only release. |
| 2025–26 | Yes | No separate file supplied | Most recent institution release. |

Expected source-file totals are 3,471 institution snapshots and 131,523 program snapshot records before MySQL removes any duplicate primary keys or rejects rows that lack a valid referenced institution.

## If local loading is disabled

Run this once inside MySQL using an administrator account:

```sql
SET GLOBAL local_infile = 1;
```

Then exit MySQL and run the PowerShell import command again. The command already enables local loading on the client side.

## Important folder rule

Do not move individual CSV or SQL files out of their folders. The master file uses relative paths, so the included folder structure must remain intact.

