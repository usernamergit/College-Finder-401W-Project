-- Existing database: no CSV reload, no table drops, no data deletion.
SOURCE sql/06_analytics.sql
SOURCE FINAL_VALIDATION.sql
SOURCE sql/07_analytics_checks.sql
