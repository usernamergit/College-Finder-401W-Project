USE new_england_college_data;
SELECT 'institutions' AS item,COUNT(*) AS row_count FROM institution
UNION ALL SELECT 'institution snapshots',COUNT(*) FROM institution_snapshot
UNION ALL SELECT 'program snapshots',COUNT(*) FROM program_snapshot;
-- Aggregate before joining: avoids multiplying all program rows by all institutions.
SELECT r.release_id,r.institution_academic_year,r.program_academic_year,
 COALESCE(i.row_count,0) AS institution_snapshots,
 COALESCE(p.row_count,0) AS program_snapshots
FROM source_release r
LEFT JOIN (SELECT release_id,COUNT(*) AS row_count FROM institution_snapshot GROUP BY release_id) i
 ON i.release_id=r.release_id
LEFT JOIN (SELECT release_id,COUNT(*) AS row_count FROM program_snapshot GROUP BY release_id) p
 ON p.release_id=r.release_id
ORDER BY r.release_date,r.release_id;
SELECT COUNT(*) AS orphaned_program_rows FROM program_snapshot p
LEFT JOIN institution i ON i.unit_id=p.unit_id WHERE i.unit_id IS NULL;
