USE new_england_college_data;

-- Choose one release per institution/year before LAG; do not merge separate years.
CREATE OR REPLACE VIEW v_institution_annual AS
WITH ranked AS (
 SELECT s.*, r.institution_academic_year AS academic_year,
 CAST(SUBSTRING(r.institution_academic_year,1,4) AS UNSIGNED) AS year_start,
 ROW_NUMBER() OVER (
   PARTITION BY s.unit_id, r.institution_academic_year
   ORDER BY r.release_date DESC, r.release_id DESC
 ) AS release_rank
 FROM institution_snapshot s
 JOIN source_release r ON r.release_id=s.release_id
 WHERE r.institution_academic_year IS NOT NULL
)
SELECT * FROM ranked WHERE release_rank=1;

CREATE OR REPLACE VIEW v_institution_yearly_changes AS
WITH previous_data AS (
 SELECT a.*,
 LAG(year_start) OVER (PARTITION BY unit_id ORDER BY year_start) AS previous_year,
 LAG(undergraduate_enrollment) OVER (PARTITION BY unit_id ORDER BY year_start) AS previous_enrollment,
 LAG(in_state_tuition) OVER (PARTITION BY unit_id ORDER BY year_start) AS previous_tuition
 FROM v_institution_annual a
), changes AS (
 SELECT p.*,
 CASE WHEN year_start=previous_year+1 THEN
   CAST(undergraduate_enrollment AS SIGNED)-CAST(previous_enrollment AS SIGNED)
 END AS enrollment_change,
 CASE WHEN year_start=previous_year+1 THEN ROUND(
   100.0*(CAST(undergraduate_enrollment AS SIGNED)-CAST(previous_enrollment AS SIGNED))
   /NULLIF(previous_enrollment,0),2)
 END AS enrollment_growth_pct,
 CASE WHEN year_start=previous_year+1 THEN in_state_tuition-previous_tuition
 END AS tuition_change,
 CASE WHEN year_start=previous_year+1 THEN ROUND(
   100.0*(in_state_tuition-previous_tuition)/NULLIF(previous_tuition,0),2)
 END AS tuition_growth_pct
 FROM previous_data p
)
SELECT changes.*,
 CASE WHEN enrollment_growth_pct IS NULL THEN 'Insufficient data'
      WHEN enrollment_growth_pct>2 THEN 'Growing'
      WHEN enrollment_growth_pct< -2 THEN 'Declining'
      ELSE 'Stable' END AS enrollment_trend
FROM changes;

-- Latest available RELEASE for each dataset, not the latest release of any kind.
CREATE OR REPLACE VIEW v_latest_institution_release AS
SELECT r.release_id,r.release_date,r.institution_academic_year
FROM source_release r
WHERE EXISTS (SELECT 1 FROM institution_snapshot s WHERE s.release_id=r.release_id)
ORDER BY CAST(SUBSTRING(r.institution_academic_year,1,4) AS UNSIGNED) DESC,
 r.release_date DESC,r.release_id DESC LIMIT 1;

CREATE OR REPLACE VIEW v_latest_program_release AS
SELECT r.release_id,r.release_date,r.program_academic_year
FROM source_release r
WHERE EXISTS (SELECT 1 FROM program_snapshot p WHERE p.release_id=r.release_id)
ORDER BY CAST(SUBSTRING(r.program_academic_year,1,4) AS UNSIGNED) DESC,
 r.release_date DESC,r.release_id DESC LIMIT 1;

CREATE OR REPLACE VIEW v_college_latest AS
SELECT i.unit_id,i.institution_name,i.city,i.state_code,i.institution_url,
 a.release_id,a.academic_year,a.undergraduate_enrollment,
 a.in_state_tuition,a.out_of_state_tuition,a.admission_rate,
 a.enrollment_change,a.enrollment_growth_pct,a.tuition_change,a.tuition_growth_pct,
 a.enrollment_trend,
 ROUND(100.0*a.admission_rate,2) AS admission_rate_pct,
 ROUND(100.0*COALESCE(a.full_time_retention_4yr,a.full_time_retention_lt4yr),2) AS retention_rate_pct,
 ROUND(100.0*COALESCE(a.completion_rate_150_4yr,a.completion_rate_150_lt4yr),2) AS completion_rate_pct
FROM institution i JOIN v_institution_yearly_changes a ON a.unit_id=i.unit_id
JOIN v_latest_institution_release r ON r.release_id=a.release_id;

CREATE OR REPLACE VIEW v_program_search AS
SELECT i.unit_id,i.institution_name,i.state_code,c.cip_code,c.cip_display,
 c.cip_description,cl.credential_level_id,cl.credential_description,
 r.release_id,r.program_academic_year,p.awards_year_1,p.awards_year_2,
 p.median_debt,p.median_earnings_1yr,p.median_earnings_4yr,p.median_earnings_5yr
FROM program_snapshot p
JOIN institution i ON i.unit_id=p.unit_id
JOIN cip_code c ON c.cip_code=p.cip_code
JOIN credential_level cl ON cl.credential_level_id=p.credential_level_id
JOIN source_release r ON r.release_id=p.release_id;

-- Replace unsafe unsigned subtraction in the older descriptive release view.
-- Release-to-release awards are NOT annual enrollment or verified annual awards.
CREATE OR REPLACE VIEW v_program_release_change AS
WITH previous_data AS (
 SELECT p.*,r.release_date,
 LAG(p.awards_year_2) OVER (
 PARTITION BY p.unit_id,p.cip_code,p.credential_level_id
 ORDER BY r.release_date,r.release_id) AS previous_release_awards
 FROM program_snapshot p JOIN source_release r ON r.release_id=p.release_id
)
SELECT unit_id,cip_code,credential_level_id,release_id,release_date,
 awards_year_2 AS current_awards,previous_release_awards,
 CAST(awards_year_2 AS SIGNED)-CAST(previous_release_awards AS SIGNED) AS awards_change
FROM previous_data;
