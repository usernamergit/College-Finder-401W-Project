USE new_england_college_data;
-- Inspect duplicates: the view deterministically selects the latest release.
SELECT s.unit_id,r.institution_academic_year,COUNT(*) AS releases
FROM institution_snapshot s JOIN source_release r ON r.release_id=s.release_id
GROUP BY s.unit_id,r.institution_academic_year HAVING COUNT(*)>1;
SELECT academic_year,COUNT(*) AS institutions,
 SUM(undergraduate_enrollment IS NULL) AS missing_enrollment,
 SUM(in_state_tuition IS NULL) AS missing_tuition
FROM v_institution_annual GROUP BY academic_year ORDER BY academic_year;
-- Expected zero: no annual calculation across missing years.
SELECT COUNT(*) AS invalid_gap_calculations FROM v_institution_yearly_changes
WHERE year_start<>previous_year+1 AND
 (enrollment_growth_pct IS NOT NULL OR tuition_growth_pct IS NOT NULL);
SELECT i.institution_name,y.academic_year,y.undergraduate_enrollment,
 y.enrollment_change,y.enrollment_growth_pct,y.in_state_tuition,
 y.tuition_growth_pct,y.enrollment_trend
FROM v_institution_yearly_changes y JOIN institution i ON i.unit_id=y.unit_id
WHERE i.institution_name='Rhode Island College' ORDER BY y.year_start;
