# Validation — October 29, 2026

## Passed

- Django configuration check: no issues.
- Python compilation: demo and three ETL scripts.
- ETL syntax parsed using Python 3.10 grammar (including compatibility fixes for older f-string parsing).
- Eleven executable synthetic tests: enrollment and tuition growth, duplicate-year release resolution, gaps, declines, missing data, zero denominators, separate latest releases by dataset, search filters and SQL-injection input, HTTP pages and 404, invalid selections, CSV export/zero rendering, and declining release awards.
- Analytics SQL executed against an isolated SQLite fixture after removing only `USE` and replacing `CREATE OR REPLACE VIEW` with `CREATE VIEW`. This tests calculations and app behavior but does not establish MySQL-specific compatibility.
- Package audit: 25 referenced SQL files; 47 CSV files; 437 unique institution IDs across all included institution files. CSV column widths and within-file primary keys passed. Every program institution ID exists in the included institution union.
- Input totals: 131,523 program snapshot rows and 3,471 institution snapshot rows. Actual database counts can differ when records already exist.

## Still required on the group's computer

- Execute `Run-Database.ps1` against the existing MySQL 8.0+ server; inspect validation output and errors.
- Test real HTTP requests against that MySQL database.
- Check the PowerShell launcher on Windows (not available in this execution environment).
- Inspect charts in a browser and verify screenshot layout with the group's existing CSS.
- Merge the separate analytics app into Kyle/Chris's complete project.
- Verify source publication dates, metric cohort years, historical CIP definitions, and program award-year mappings against the original dictionaries before making definitive annual program claims.

## Reproduce

From the extracted package root: `python audit_package.py`.

Inside `web_demo`, after installing requirements: `python run_tests.py` and `python manage.py check`.

Tests use a synthetic in-memory database and do not write to the group's MySQL database.
