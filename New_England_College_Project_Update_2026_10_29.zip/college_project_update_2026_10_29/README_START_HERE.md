# College Project — October 29, 2026 update

This is an updated database package plus a standalone Django analytics demo and a reusable analytics app. It includes the available earlier ETL code, schema, import files, and data. It does not pretend to be a full reconstruction of your teammates' website: uploads contain colliding app filenames and an incomplete project structure. Original Python/HTML fragments are in `teammate_reference` for reference, with credentials removed.

## 1. Update the database you already imported

Extract the ZIP. Open the `mysql_database` folder in VS Code and run in PowerShell:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Run-Database.ps1
```

If MySQL is not found or multiple versions are installed:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Run-Database.ps1 -MySqlPath 'C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe'
```

This applies analytics views and checks; it does not reload CSVs or delete records. Review the output for errors. For a NEW database only, add `-FullImport`. Full imports require server-side `local_infile=ON`; the script already enables the client option. To enable the server setting, log into MySQL as an administrator and execute `SET GLOBAL local_infile=1;`.

If you renamed folders in an old package, extract this update separately and keep its paths intact. Use this new folder for the commands.

## 2. Run the included analytics demo

Open a PowerShell terminal inside `web_demo`. Requires Python 3.10+ and your imported MySQL 8.0+ database.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:DB_USER = 'root'
$env:DB_PASSWORD = [System.Net.NetworkCredential]::new('', (Read-Host 'MySQL password' -AsSecureString)).Password
.\.venv\Scripts\python.exe manage.py check
.\.venv\Scripts\python.exe manage.py runserver
```

Open http://127.0.0.1:8000/analytics/ . MySQL must be running. The analytics app reads existing tables and views; it does not need migrations. `check` validates Django configuration; loading a page tests actual database queries. The included settings are for local development only.

## 3. Add the analytics app to Kyle's existing project

Copy only `web_demo/analytics` into the same directory as his `manage.py`. Do not overwrite his existing apps, models, settings, or project URL file. Install the dependencies from the requirements file in his environment. If he already has a working mysqlclient driver, keep it; PyMySQL is the demo's alternative.

Append `analytics` to `INSTALLED_APPS`. In the project's URL file add:

```python
from django.urls import include, path
# Add this entry to the EXISTING urlpatterns list:
path('analytics/', include('analytics.urls')),
```

Use the project's working MySQL connection. The app uses `default` unless settings define `COLLEGE_DB_ALIAS = 'college'` (for a separately configured database alias named `college`). Keep passwords in environment variables, following the demo settings example. No analytics ORM models are added; read-only parameterized queries handle the composite-key tables directly. Django authentication/resume/job migrations remain the responsibility of the existing apps.

## Features included

- College search by name, state, and imported academic year.
- Program search by description/college, state, credential, and imported program-year label.
- Annual enrollment and nominal tuition differences and percentage changes.
- Deterministic selection of one release per college/year before calculations.
- No annual calculation across a missing year, zero denominator, or missing value.
- Growing (>2%), stable (−2% through 2%), declining (<−2%) labels. These are prototype thresholds, not an official standard or program closure recommendation.
- College history tables and SVG charts; gaps are not connected.
- Comparison of up to three colleges in the SAME year.
- CSV exports of displayed search results (200 maximum) and college history.
- Missing values display as N/A, while zero remains zero.
- Validation counts aggregated before joining to avoid an institution/program cross product.

## Calculations and interpretation

Enrollment change = current undergraduate enrollment − previous enrollment.
Enrollment growth % = 100 × change / previous enrollment.
Tuition growth uses the same formula with in-state tuition. Dollar amounts are nominal, not inflation-adjusted. Rate fields are stored as fractions; the latest-college view also exposes rates × 100 for display.

Institution enrollment is institution-wide, not major enrollment. Program award counts are not counts of students entering or leaving a major. Annual program growth remains intentionally unavailable until the source glossaries establish the actual award years and overlapping cohorts for every release. The older `v_program_release_change` is only a descriptive release-to-release difference, not verified annual growth.

Academic-year and release-date labels inherited from the earlier loaders have NOT been independently verified against the original source dictionaries. Some historical release dates were supplied as loader metadata. Do not claim these are verified publication dates or that every metric is from the displayed year. Verify before a final presentation. CIP descriptions/classifications also need review where historical releases use different CIP versions; matching code strings alone may not establish consistent program definitions.

Coverage remains the earlier supplied coverage: matched 2016–17 through 2022–23 files, later institution releases, a 2015–16 field subset without a same-year institution file, and the previous most-recent program package. No new external data was fetched. Historical program presence does not prove current offerings, and absence does not prove discontinuation. Outcomes are cohort statistics, not job guarantees. Resume and job-finder fragments are preserved; no new live job API or resume-builder completion is claimed.

## This week's completion checklist (October 26–November 1)

1. Apply the update and save validation output.
2. Test RIC and two other colleges, including a declining enrollment case.
3. Verify displayed differences with hand calculations.
4. Have Kyle add the analytics app and Chris adapt the presentation to the group's design.
5. Verify actual program award year mappings using source glossaries.
6. Test an invalid state/year, no matches, missing values, comparison, and CSV export.
7. Capture real working-page screenshots and record actual work hours.

## Documentation sources

- https://docs.djangoproject.com/en/5.2/topics/db/sql/
- https://docs.djangoproject.com/en/5.2/topics/db/multi-db/
- https://dev.mysql.com/doc/refman/8.0/en/window-function-descriptions.html

Read `TEST_RESULTS.md` for exactly what was tested and what still requires your MySQL server.
